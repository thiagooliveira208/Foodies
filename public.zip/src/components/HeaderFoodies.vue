<template>
  <div class="header-foodies">
    <h1 class="title">Foodies</h1>
    <div class="menu">
      <span class="material-symbols-outlined menubar"> menu </span>
    </div>
  </div>
</template>

<script>
export default {
  name: "HeaderFoodies",
};
</script>

<style lang="scss" scoped>
.header-foodies {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  height: 86px;

  background: #f3fcf7;

  > .title {
    width: 70%;
    padding: 25px 0;

    font-family: "Inter";
    font-size: 32px;
    font-weight: 500;
    color: #06c167;
  }

  > .menu {
    width: 47px;
    height: 39px;
    align-self: center;
    text-align: center;

    color: #06c167;

    border: 2px solid #06c167;

    > .menubar {
      padding-top: 3px;
      font-size: 32px;
    }
  }
}
</style>
