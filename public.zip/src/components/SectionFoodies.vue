<template>
  <div class="section-foodies">
    <div v-if="subtitle" class="subtitle">{{ subtitle }}</div>
    <div v-if="title" class="title" :class="{ '-smalltitle': smalltitle }">
      {{ title }}
    </div>
    <div v-if="description" class="description">{{ description }}</div>
    <button-foodies
      v-if="actionButton"
      class="action-button"
      :class="{ '-actionbuttonbottom': actionButtonBottom }"
      primary
      block
    >
      {{ actionButtonText }}
    </button-foodies>

    <div
      class="illustration"
      :class="{
        '-illustrationbottom': illustrationBottom,
        '-illustrationtop': illustrationTop,
        '-illustrationlarge': illustrationLarge,
        '-illustrationsmall': illustrationSmall,
      }"
      v-if="illustration"
    >
      <img class="image-main" :src="srcImgMain" />
      <img
        class="image-effect"
        src="@/assets/images/polcadot.png"
        v-show="polcadot"
      />

      <div class="ratings" v-show="ratings">
        5.0 Ratings
        <div class="stars">
          <span class="material-symbols-outlined star"> star </span>
          <span class="material-symbols-outlined star"> star </span>
          <span class="material-symbols-outlined star"> star </span>
          <span class="material-symbols-outlined star"> star </span>
          <span class="material-symbols-outlined star"> star </span>
        </div>
      </div>

      <div class="quality" v-show="quality">
        <img class="image-effect" src="@/assets/images/mulher_2.png" />
        Good Quality Product
      </div>
    </div>

    <div class="content">
      <slot />
    </div>
  </div>
</template>

<script>
import ButtonFoodies from "@/components/ButtonFoodies.vue";

export default {
  name: "SectionFoodies",

  components: {
    ButtonFoodies,
  },

  props: {
    title: {
      type: String,
      default: "",
    },
    smalltitle: {
      type: Boolean,
      default: false,
    },
    subtitle: {
      type: String,
      default: "",
    },
    description: {
      type: String,
      default: "",
    },
    srcImg: {
      type: String,
      default: null,
    },
    actionButton: {
      type: Boolean,
      default: false,
    },
    actionButtonText: {
      type: String,
      default: "",
    },
    actionButtonBottom: {
      type: Boolean,
      default: false,
    },
    illustration: {
      type: Boolean,
      default: false,
    },
    illustrationBottom: {
      type: Boolean,
      default: false,
    },
    illustrationTop: {
      type: Boolean,
      default: false,
    },
    illustrationLarge: {
      type: Boolean,
      default: false,
    },
    illustrationSmall: {
      type: Boolean,
      default: false,
    },
    polcadot: {
      type: Boolean,
      default: false,
    },
    ratings: {
      type: Boolean,
      default: false,
    },
    quality: {
      type: Boolean,
      default: false,
    },
  },

  data() {
    return {
      srcImgMain: require(`@/assets/images/${this.srcImg}`),
    };
  },
};
</script>

<style lang="scss" scoped>
.section-foodies {
  position: relative;
  display: flex;
  flex-direction: column;
  background: none;
  font-family: "Inter";

  $limitdivchild: 6;

  @for $order from 0 through $limitdivchild {
    > *:nth-child(#{$order}) {
      order: calc($order * 10);
    }
  }

  > .subtitle {
    margin: 25px 0;
    font-size: 15px;
    font-weight: 500;
    line-height: 18px;
    text-align: center;
  }

  > .title {
    margin: 25px 0;
    font-size: 51px;
    font-weight: 600;
    line-height: 62px;
    text-align: center;

    &.-smalltitle {
      margin: 0;
      font-size: 35px;
      font-weight: 500;
      line-height: 42px;
    }
  }

  > .description {
    margin: 25px 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 22px;
    text-align: center;
  }

  > .action-button {
    margin-top: 15%;
    margin-bottom: 15%;

    &.-actionbuttonbottom {
      order: 90;
    }
  }

  > .illustration {
    &.-illustrationbottom {
      position: relative;
      margin-bottom: 10%;

      > .image-main {
        width: 100%;
        margin-top: 15%;
      }

      > .image-effect {
        position: absolute;
        width: 44%;

        bottom: 0;
        right: 0;
      }

      > .ratings {
        position: absolute;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        column-gap: 10px;
        width: 75%;
        height: 11%;

        bottom: 15%;
        right: 10%;

        background: #fff;

        font-size: 15px;
        font-weight: 500;

        border-radius: 25px;

        > .stars {
          color: #06c167;
        }
      }

      > .quality {
        position: absolute;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        column-gap: 20px;
        width: 75%;
        height: 11%;

        bottom: 0;
        right: 10%;

        background: #fff;

        font-size: 15px;
        font-weight: 500;

        border-radius: 25px;

        box-shadow: 0px 4px 13px rgba(0, 0, 0, 0.1);
      }
    }

    &.-illustrationtop {
      display: flex;
      justify-content: center;
      margin-top: 30%;
      margin-bottom: 10%;
      background: #f0f1ec;
      order: -1;

      > .image-main {
        width: 85%;
        transform: translateY(-6%);
      }

      &.-illustrationlarge {
        height: 380px;
      }

      &.-illustrationsmall {
        height: 400px;
      }
    }
  }

  > .content {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-evenly;
    column-gap: 20%;
    padding-top: 5%;
  }
}
</style>
